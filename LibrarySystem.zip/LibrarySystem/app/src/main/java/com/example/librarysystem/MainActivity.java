package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(MainActivity.this);
        db.initialdata();

        Button createAccountButton = findViewById(R.id.createaccountbutton);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCreateAccountActivity();
            }
        });

        Button placeHoldButton = findViewById(R.id.placeholdbutton);
        placeHoldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPlaceHoldActivity();
            }
        });

        Button manageSystemButton = findViewById(R.id.managesystembutton);
        manageSystemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openManageSystemActivity();
            }
        });
    }

    private void openCreateAccountActivity() {
        Intent intent = new Intent(MainActivity.this, CreateAccount.class);
        startActivity(intent);
    }

    private void openPlaceHoldActivity() {
        Intent intent = new Intent(MainActivity.this, PlaceHold.class);
        startActivity(intent);
    }

    private void openManageSystemActivity() {
        Intent intent = new Intent(MainActivity.this, ManageSystem.class);
        startActivity(intent);
    }
}