package com.example.librarysystem;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BookDao {
    @Insert
    void insertBook(Book book);

    @Update
    void updateBook(Book book);

    @Delete
    void deleteBook(Book book);

    @Query("SELECT * FROM Books WHERE id = :id")
    Book getBookById(int id);

    @Query("SELECT * FROM Books")
    List<Book> getAllBooks();
    @Query("SELECT COUNT(*) FROM Books")
    int count();
    @Query("SELECT * FROM Books WHERE title = :title")
    Book getBookByTitle(String title);

    @Query("SELECT DISTINCT genre FROM Books")
    List<String> getAllGenres();

    @Query("SELECT * FROM books WHERE genre = :genre")
    List<Book> getBooksByGenre(String genre);

    @Query("SELECT * FROM Books WHERE reserved = 1")
    List<Book> getBooksOnHold();

    @Query("UPDATE Books SET reserved = 0 WHERE id = :bookId")
    void removeHold(int bookId);
}