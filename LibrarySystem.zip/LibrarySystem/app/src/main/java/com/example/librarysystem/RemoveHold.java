package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class RemoveHold extends AppCompatActivity {
    private AppDatabase databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_hold);

        databaseHelper = AppDatabase.getInstance(this);

        ListView holdListView = findViewById(R.id.hold_list_view);

        List<Book> booksOnHold = databaseHelper.bookDao().getBooksOnHold();

        ArrayAdapter<Book> bookAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, booksOnHold);
        holdListView.setAdapter(bookAdapter);

        holdListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book selectedBook = (Book) parent.getItemAtPosition(position);

                databaseHelper.bookDao().removeHold(selectedBook.getId());

                booksOnHold.remove(selectedBook);
                bookAdapter.notifyDataSetChanged();
            }
        });
    }
}
