package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.List;

public class PlaceHold extends AppCompatActivity {
    private AppDatabase databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_hold);

        Button removeHoldButton = findViewById(R.id.remove_hold_button);
        removeHoldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlaceHold.this, RemoveHold.class);
                startActivity(intent);
            }
        });

        databaseHelper = AppDatabase.getInstance(this);
        Spinner genreSpinner = findViewById(R.id.spinnerBookCategory);
        Button selectBookButton = findViewById(R.id.select_book_button);

        List<String> genres = databaseHelper.bookDao().getAllGenres();

        ArrayAdapter<String> genreAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, genres);
        genreAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genreSpinner.setAdapter(genreAdapter);

        selectBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedGenre = genreSpinner.getSelectedItem().toString();

                Intent intent = new Intent(PlaceHold.this, BookSelection.class);
                intent.putExtra("genre", selectedGenre);
                startActivity(intent);
            }
        });
    }
}
