package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

public class BookSelection extends AppCompatActivity {
    private AppDatabase database;
    private EditText bookTitleEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_selection);

        Button deleteButton = findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBook();
            }
        });

        database = AppDatabase.getInstance(this);

        bookTitleEditText = findViewById(R.id.book_title_edit_text);
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);

        String selectedGenre = getIntent().getStringExtra("genre");

        List<Book> bookList = database.bookDao().getBooksByGenre(selectedGenre);

        if (bookList.isEmpty()) {
            showNoBooksAvailableMessage();
        } else {
            boolean anyBookAvailable = false;
            for (Book book : bookList) {
                if (!book.isReserved()) {
                    anyBookAvailable = true;
                    break;
                }
            }
            if (anyBookAvailable) {
                Button reserveButton = findViewById(R.id.reserve_button);
                reserveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        reserveBook();
                    }
                });
            } else {
                showNoBooksAvailableMessage();
            }
        }
    }

    private void reserveBook() {
        String bookTitle = bookTitleEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (!bookTitle.isEmpty() && !username.isEmpty() && !password.isEmpty()) {
            Book selectedBook = database.bookDao().getBookByTitle(bookTitle);

            if (selectedBook != null) {
                if (selectedBook.isReserved()) {
                    showBookReservedMessage();
                } else {
                    if (database.userDao().isValidUser(username, password)) {
                        int reservationNumber = generateReservationNumber();

                        String confirmationMessage = "Customer username: " + username + "\n" +
                                "Book Title: " + selectedBook.getTitle() + "\n" +
                                "Reservation number: " + reservationNumber;
                        Toast.makeText(this, confirmationMessage, Toast.LENGTH_LONG).show();

                        selectedBook.setReserved(true);
                        database.bookDao().updateBook(selectedBook);

                        storeTransaction("Place Hold", username, reservationNumber);

                        Intent intent = new Intent(BookSelection.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(this, "Invalid book title", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        }
    }

    private int generateReservationNumber() {
        return new Random().nextInt(900) + 100;
    }

    private void storeTransaction(String transactionType, String username, int reservationNumber) {
        Transaction transaction = new Transaction(transactionType, username, reservationNumber);
        database.transactionDao().insertTransaction(transaction);
    }

    private void showNoBooksAvailableMessage() {
        Toast.makeText(this, "No books available in this genre", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(BookSelection.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void showBookReservedMessage() {
        Toast.makeText(this, "The selected book is already reserved", Toast.LENGTH_SHORT).show();
    }

    private void deleteBook() {
        String bookTitle = bookTitleEditText.getText().toString();

        if (!bookTitle.isEmpty()) {
            Book selectedBook = database.bookDao().getBookByTitle(bookTitle);

            if (selectedBook != null) {
                if (selectedBook.isReserved()) {
                    Toast.makeText(this, "Cannot delete a reserved book", Toast.LENGTH_SHORT).show();
                } else {
                    database.bookDao().deleteBook(selectedBook);
                    Toast.makeText(this, "Book deleted successfully", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Invalid book title", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter a book title", Toast.LENGTH_SHORT).show();
        }
    }


}
