package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class ManageSystem extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private AppDatabase database;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system);

        database = AppDatabase.getInstance(this);

        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);

        Button loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginToSystem();
            }
        });
    }

    private void loginToSystem() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (isValidCredentials(username, password)) {
            displayLogInformation();
            int res = generateReservationNumber();
            String newUsername = database.transactionDao().getNewlyAddedCustomerUsername();

            String confirmationMessage = "Transaction Type: " + database.transactionDao().getTransactionType() + "\n" + "Customer username: " + newUsername;

            Toast.makeText(this, confirmationMessage, Toast.LENGTH_SHORT).show();

            storeTransaction("New Account", username, res);
        } else {
            handleInvalidCredentials();
        }
    }

    private boolean isValidCredentials(String username, String password) {
        return username.equals("!admin2") && password.equals("!admin2");
    }

    private void displayLogInformation() {
        addNewBookInformation();
    }

    private void addNewBookInformation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Book");
        builder.setMessage("Do you have a new book to add to the system?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showAddBookDialog();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(ManageSystem.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        builder.create().show();
    }

    private void showAddBookDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Book");
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_book, null);
        builder.setView(dialogView);

        EditText titleEditText = dialogView.findViewById(R.id.title_edit_text);
        EditText authorEditText = dialogView.findViewById(R.id.author_edit_text);
        EditText genreEditText = dialogView.findViewById(R.id.genre_edit_text);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String title = titleEditText.getText().toString();
                String author = authorEditText.getText().toString();
                String genre = genreEditText.getText().toString();

                if (isValidBookInfo(title, author, genre)) {
                    addBookToSystem(title, author, genre);
                } else {
                    handleInvalidBookInfo();
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.create().show();
    }

    private boolean isValidBookInfo(String title, String author, String genre) {
        return !title.isEmpty() && !author.isEmpty() && !genre.isEmpty();
    }

    private void addBookToSystem(String title, String author, String genre) {
        Book book = new Book(title, author, genre);

        database.bookDao().insertBook(book);

        int res = generateReservationNumber();

        String username = database.transactionDao().getUserByUsername(this.username).getUsername();;
        String confirmationMessage = "Transaction Type: " + database.transactionDao().getTransactionType() + "\n" + "Customer username: " + username;

        Toast.makeText(this, confirmationMessage, Toast.LENGTH_SHORT).show();

        storeTransaction("New Book", username, res);

        Toast.makeText(this, "New book added to the system: " + title, Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(ManageSystem.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void handleInvalidCredentials() {
        Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ManageSystem.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void handleInvalidBookInfo() {
        Toast.makeText(this, "Invalid book information", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ManageSystem.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

//    private void showMainMenu() {
//        Intent intent = new Intent(ManageSystem.this, MainActivity.class);
//        startActivity(intent);
//        finish();
//    }

    private void storeTransaction(String transactionType, String username, int reservationNumber) {
        Transaction transaction = new Transaction(transactionType, username, reservationNumber);

        database.transactionDao().insertTransaction(transaction);
    }
    private int generateReservationNumber() {
        return new Random().nextInt(900) + 100;
    }
}
