package com.example.librarysystem;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, Book.class, Transaction.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase instance;
    public abstract UserDao userDao();
    public abstract TransactionDao transactionDao();

    public abstract BookDao bookDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "library_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }

    public void initialdata() {

        runInTransaction(() -> {
            if (userDao().count() == 0) {
                userDao().insertUser(new User("anton", "t3nn1s23"));
                userDao().insertUser(new User("bernie", "ind1em3d$"));
                userDao().insertUser(new User("shirleybee", "carmel2chicago"));
            }
            if (bookDao().count() == 0) {
                bookDao().insertBook(new Book("Angela's Ashes", "Frank McCourt", "Memoir"));
                bookDao().insertBook(new Book("Head First Java", "Kathy Sierra", "Computer Science"));
                bookDao().insertBook(new Book("A Little Life", "Hanya Yanagihara", "Fiction"));
            }

        });
    }

}
