package com.example.librarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class CreateAccount extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button createAccountButton;
    private AppDatabase appDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        appDatabase = AppDatabase.getInstance(this);

        usernameEditText = findViewById(R.id.usernameid);
        passwordEditText = findViewById(R.id.passwordid);
        createAccountButton = findViewById(R.id.createbutton);

        Button deleteAccountButton = findViewById(R.id.deletebutton);
        deleteAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteUser();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(CreateAccount.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                } else {
                    User existingUser = appDatabase.userDao().getUserByUsername(username);

                    if (existingUser != null) {
                        Toast.makeText(CreateAccount.this, "Username already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        User newUser = new User(username, password);
                        appDatabase.userDao().insertUser(newUser);

                        Toast.makeText(CreateAccount.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                        int res = generateReservationNumber();
                        storeTransaction("New Account", username, res);

                    }
                    Intent intent = new Intent(CreateAccount.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    private void storeTransaction(String transactionType, String username, int reservationNumber) {
        Transaction transaction = new Transaction(transactionType, username, reservationNumber);
        appDatabase.transactionDao().insertTransaction(transaction);
    }

    private int generateReservationNumber() {
        return new Random().nextInt(900) + 100;
    }

    private void deleteUser() {
        String username = usernameEditText.getText().toString().trim();
        User existingUser = appDatabase.userDao().getUserByUsername(username);

        if (existingUser != null) {
            appDatabase.userDao().deleteUser(existingUser);
            Toast.makeText(CreateAccount.this, "Account deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(CreateAccount.this, "User not found", Toast.LENGTH_SHORT).show();
        }
    }
}