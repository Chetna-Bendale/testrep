package com.example.librarysystem;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Query("SELECT * FROM Users WHERE username = :username")
    User getUserByUsername(String username);

    @Insert
    void insertUser(User user);

    @Delete
    void deleteUser(User user);

    @Query("SELECT COUNT(*) FROM Users")
    int count();

    @Query("SELECT COUNT(*) FROM Users WHERE username = :username AND password = :password")
    boolean isValidUser(String username, String password);

}
