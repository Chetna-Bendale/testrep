package com.example.librarysystem;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface TransactionDao {
    @Insert
    void insertTransaction(Transaction transaction);

    @Delete
    void deleteTransaction(Transaction transaction);

    @Query("SELECT TransactionType FROM transactions WHERE id = (SELECT max(id) FROM transactions)")
    String getTransactionType();

    @Query("SELECT * FROM Users WHERE username = :username")
    User getUserByUsername(String username);

    @Query("SELECT username FROM Transactions ORDER BY id DESC LIMIT 1")
    String getNewlyAddedCustomerUsername();
}
