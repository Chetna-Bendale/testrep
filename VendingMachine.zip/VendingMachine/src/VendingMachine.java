/*
Title: VendingMachine.java
Abstract: This program is a simulation of a vending machine that allows users to select items, make payments, and generate receipts.
Author: Chetna Bendale
Date: 02/24/2023
 */


import java.util.Arrays;
import java.util.Scanner;

public class VendingMachine {
    private String location;
    private int serialNumber;
    private int[] qty = {0, 0, 0, 0};
    private String[] Contents = {"Water", "Coffee", "Chips", "Chocolate"};
    private String[] contents = {"water", "coffee", "chips", "chocolate"};
    private double[] amounts = {1.50, 2.00, 1.00, 2.50};
    private double total;
    private int[] quantitySold={0,0,0,0};
    private int[] cart = new int[4];

    public VendingMachine(int serialNumber) {
        this.serialNumber = serialNumber;
        this.location = "UNKNOWN";
    }

    public VendingMachine(int serialNumber, String location) {
        this.serialNumber = serialNumber;
        this.location = location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    public void setName(int name) {
        this.serialNumber = name;
    }

    public void reset(int Water, int Coffee, int Chips, int Chocolate) {
        qty[0] = Water;
        qty[1] = Coffee;
        qty[2] = Chips;
        qty[3] = Chocolate;
    }

    public void addItems(int Water, int Coffee, int Chips, int Chocolate) {
        qty[0] += Water;
        qty[1] += Coffee;
        qty[2] += Chips;
        qty[3] += Chocolate;
    }

    public void displayMenu() {
        System.out.println("""
                ===== Vending Machine Menu =====     
                 1. Water............$1.50   
                 2. Coffee...........$2.00   
                 3. Chips............$1.00
                 4. Chocolate........$2.50
                 """);
    }

    public boolean buyItem() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter item number: ");
        int itemNum = sc.nextInt();
        System.out.print("How many do you want to buy? ");
        int qtyss = sc.nextInt();
        if (qty[itemNum - 1] < qtyss) {
            System.out.println("Selection failed. We do not have enough " + contents[itemNum - 1]);
            return false;
        }
        double itemPrice = amounts[itemNum - 1] * qtyss;
        System.out.println("You selected " + contents[itemNum - 1] + ". Quantity: " + qtyss);
        qty[itemNum - 1] -= qtyss;
        total += itemPrice;
        quantitySold[itemNum - 1] += qtyss;
        cart[itemNum - 1] += qtyss;
        return true;
    }

    public boolean buyItem(int itemNum, int quanty) {
        System.out.println("Enter item number: " + itemNum);
        System.out.println("How many do you want to buy? " + quanty);
        if (this.qty[itemNum - 1] < quanty) {
            System.out.println("You selected " + contents[itemNum - 1] + ". Quantity: " + quanty);
            System.out.println("Selection failed. We do not have enough " + contents[itemNum - 1] + ".");
            return false;
        }

        double item$ = amounts[itemNum - 1] * quanty;
        System.out.println("You selected " + contents[itemNum - 1] + ". Quantity: " + quanty);
        qty[itemNum - 1] -= quanty;
        total += item$;
        quantitySold[itemNum-1] += quanty;
        cart[itemNum - 1] += quanty;
        return true;
    }
    public void returned(int itemNum, int qtys) {
        System.out.println("You selected " + contents[itemNum - 1] + ". Quantity: " + qtys + ".");
        qty[itemNum - 1] += qtys;
        double price = amounts[itemNum - 1] * qtys;
        total -= price;
        quantitySold[itemNum - 1] -= qtys;
        cart[itemNum - 1] -= qtys;
    }

    public boolean payment() {
        Scanner sc = new Scanner(System.in);

        double tax = total * 0.1;
        double grandtotal = total + tax;

        System.out.print("Enter money amount: $");
        double money = sc.nextDouble();

        if (money < grandtotal) {
            System.out.printf("Insufficient money. $%.2f returned\n", money);
            return false;
        } else {
            double change = money - grandtotal;
            System.out.printf("Sufficient money. $%.2f returned\n", change);
            return true;
        }
    }
    public void displayReceipt() {
        double tax = total * 0.1;
        double grandtotal = total + tax;
        for (int i = 0; i < cart.length; i++) {
            if (cart[i] > 0) {
                switch(i) {
                    case 0:
                        System.out.printf("Water: $%.2f X %d = $%.2f\n", amounts[i], cart[i], amounts[i]*cart[i]);
                        break;
                    case 1:
                        System.out.printf("Coffee: $%.2f X %d = $%.2f\n", amounts[i], cart[i], amounts[i]*cart[i]);
                        break;
                    case 2:
                        System.out.printf("Chips: $%.2f X %d = $%.2f\n", amounts[i], cart[i], amounts[i]*cart[i]);
                        break;
                    case 3:
                        System.out.printf("Chocolate: $%.2f X %d = $%.2f\n", amounts[i], cart[i], amounts[i]*cart[i]);
                        break;
                }
            }
        }
        System.out.printf("Tax (10.0%%): $%.2f\n", tax);
        System.out.printf("Total: $%.2f\n\n", grandtotal);
    }

    public void status() {
        double tax = total * 0.1;
        double grandtotal = total + tax;
        System.out.println("Serial Number: " + this.serialNumber);
        System.out.println("Location: " + this.location);
        System.out.println("Sold Items:");
        System.out.println("  Water: " + this.quantitySold[0]);
        System.out.println("  Cofeee: " + this.quantitySold[1]);
        System.out.println("  Chips: " + this.quantitySold[2]);
        System.out.println("  Chocolate: " + this.quantitySold[3]);
        System.out.println("Current Contents:");
        System.out.println("  Water: " + this.qty[0]);
        System.out.println("  Cofeee: " + this.qty[1]);
        System.out.println("  Chips: " + this.qty[2]);
        System.out.println("  Chocolate: " + this.qty[3]);
        System.out.printf("Total Earnings: $%.2f\n", grandtotal);
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VendingMachine that = (VendingMachine) o;
        return Arrays.equals(qty, that.qty);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(qty);
    }
    public String toString() {
        return "Serial Number: " + serialNumber + "\nLocation: " + location + "\nContents:" + "\n" + "  " + Contents[0] + ": " + qty[0] + "\n" + "  " + Contents[1] + ": " + qty[1] + "\n" + "  " + Contents[2] + ": " + qty[2] + "\n" + "  " + Contents[3] + ": " + qty[3] ;
    }
}