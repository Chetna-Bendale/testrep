public class Demo5 {
    public static void main(String[] args) {
        VendingMachine machine1 = new VendingMachine(200, "Library");
        VendingMachine machine2 = new VendingMachine(100, "Library");
        machine1.reset(5, 7, 3, 10);
        machine2.reset(5, 7, 3, 10);

        System.out.println("\n===== ANSWER: true =====");
        System.out.println(machine1.equals(machine2));
        System.out.println("========================");

        machine1.addItems(5, 5, 5, 5);
        System.out.println("\n===== ANSWER: false =====");
        System.out.println(machine1.equals(machine2));
        System.out.println("========================");

    }
}