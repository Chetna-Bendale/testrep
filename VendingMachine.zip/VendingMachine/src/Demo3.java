public class Demo3 {
  public static void main(String[] args) {
    VendingMachine machine1 = new VendingMachine(100, "MLC104");
    machine1.reset(5, 5, 5, 5);
    System.out.println("\n===== ANSWER: true =====");
    System.out.println(machine1.buyItem(2, 2));
    System.out.println("\n===== ANSWER: false =====");
    System.out.println(machine1.buyItem(4, 100));
  }
}
