public class Demo4 {
  public static void main(String[] args) {
    VendingMachine machine1 = new VendingMachine(100, "MLC104");
    machine1.reset(5, 5, 5, 5);
    machine1.buyItem(4, 5);
    System.out.println("\n===== Enter 5 for payment. =====");
    System.out.println("===== ANSWER: Insufficient money. $5.00 returned =====");
    if(machine1.payment()) {
      machine1.displayReceipt();
    } else {
      System.exit(1);
    }
  }
}
