public class Demo2 {
  public static void main(String[] args) {
    VendingMachine machine1 = new VendingMachine(100, "MLC104");
    machine1.reset(5, 5, 5, 5);
    machine1.buyItem(1, 5);
    machine1.buyItem(2, 5);
    machine1.buyItem(3, 5);
    machine1.buyItem(4, 5);
    machine1.returned(1, 5);
    machine1.returned(2, 5);
    machine1.returned(3, 5);
    machine1.returned(4, 5);
    System.out.println("\n===== ANSWER: Nothing was sold. $0.00 was earned. =====");
    machine1.status();
  }
}
