public class Demo1  {
  public static void main(String[] args) {
  VendingMachine machine1 = new VendingMachine(100, "MLC104");
  machine1.reset(5, 5, 5, 5);
  System.out.println("\n===== Enter 2 and 2 for testing. =====");
  machine1.buyItem();
  System.out.println("\n===== Enter 5 for payment. =====");
  machine1.payment();
  machine1.displayReceipt();
  System.out.println("\n===== ANSWER: $0.60 returned and two coffee ($4.40) sold =====");
  }
}
