/*
Title: Bubble.java
Abstract: This program is to define a Customer object, which represents a customer of a bank
Author: Chetna Bendale
Date: 02/24/2023
 */

public class Customer {
    private String name;
    private String address;
    private int ssn;

    public Customer(String name, String address, int ssn) {
        this.name = name;
        this.ssn = ssn;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public int getSsn() {
        return ssn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String toString() {
        return "Name: " + getName() + "\nSSN: " + getSsn() + "\nAddress: " + getAddress();
    }
}
