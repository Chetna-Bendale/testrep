

public class Demo1 {
  public static void main(String[] args) {
     Bank csumbBank = new Bank("CSUMB");
     System.out.println("\n\n========== ANSWER: 0 account and 0 total balance ==========\n");
     csumbBank.bankInfo();
     System.out.println("\n");
  }
}
