/*
Title: Bubble.java
Abstract: This program represents a bank account with account number, account type, balance, name of the account holder, Social Security Number (SSN), address, and a reference to a customer object.
Author: Chetna Bendale
Date: 02/24/2023
 */

public class Account {
    private int accNum;
    private int accType;
    private double balance;
    private String name;
    private int ssn;
    private String addr;
    private Customer accHolder;

    public Account(int accNum, int accType, double balance, String name, int ssn, String addr, Customer accHolder) {
        this.accNum = accNum;
        this.accType = accType;
        this.balance = balance;
        this.name = name;
        this.ssn = ssn;
        this.addr = addr;
        this.accHolder = accHolder;
    }

    public int getAccNum() {
        return accNum;
    }

    public int getAccType() {
        return accType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public int getSsn() {
        return ssn;
    }
    public Customer getAccHolder() {
        return accHolder;
    }

    public void setAccHolder(Customer accHolder) {
        this.accHolder = accHolder;
    }


    public void setAddr(String addr) {
        this.addr = addr;
    }


    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    public String getAccTypeString() {
        if (accType == 1) {
            return "Checking account";
        } else if (accType == 2) {
            return "Savings account";
        } else {
            return "Unknown";
        }
    }
    public String toString() {
        return "Account number: " + getAccNum() + "\nAccount type: " + getAccTypeString() + "\nBalance: " + getBalance();
    }

}