/*
Title: Bubble.java
Abstract: This program is a simulation of a bank system where it stores the information like ssn, balance and is restricted to only 5 accounts.
Author: Chetna Bendale
Date: 02/24/2023
 */

public class Bank {
    private Account[] accounts;
    private String bankName;
    private int numAccounts;
    private int ssn;
    private String addr;

    public Bank(String name) {
        accounts = new Account[5];
        bankName = name;
        numAccounts = 0;
    }

    public String getBankName() {
        return bankName;
    }

    public String getAddr() {
        return addr;
    }


    public boolean openAccount(String name, String addr, int ssn, int accNum, int accType, double balance) {
        if (numAccounts == 5) {
            return false;
        }

        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccNum() == accNum) {
                return false;
            }
        }

        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getSsn() == ssn) {
                return false;
            }
        }

        String address = addr;
        accounts[numAccounts] = new Account(accNum, accType, balance, name, ssn, addr, new Customer(name, address, ssn));
        numAccounts++;
        return true;
    }

    public boolean closeAccount(int accNum) {
        int index = -1;
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccNum() == accNum) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            return false;
        }

        for (int i = index; i < numAccounts - 1; i++) {
            accounts[i] = accounts[i + 1];
        }
        numAccounts--;
        return true;
    }

    public boolean accountInfo(int accNum) {
        int index = -1;
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccNum() == accNum) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            System.out.println("");
            return false;
        }
        Account account = accounts[index];
        String accType = account.getAccTypeString();
        System.out.println("Account Number: " + accNum);
        System.out.println(accType);
        System.out.println("Balance: $" + account.getBalance());
        System.out.println("\nCustomer: " + account.getAccHolder().getName());
        System.out.println(account.getAccHolder().getAddress());
        System.out.println("SSN: " + account.getAccHolder().getSsn());

        return true;
    }

    public void updateBalance(int accNum, double amount) {
        int index = -1;
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccNum() == accNum) {
                index = i;
                break;
            }
        }
        if (index == -1 || amount < 0) {
            System.out.println("Error: Invalid account number or balance.");
            return;
        }

        accounts[index].setBalance(amount);
        System.out.println("Balance updated for account number " + accNum + ".");
    }

    public boolean updateAddress(int accNum, String addr) {
        int index = -1;
        for (int i = 0; i < numAccounts; i++) {
            if (accounts[i].getAccNum() == accNum) {
                index = i;
                break;
            }
        }

        if (index == -1) {
            return false;
        }
        
        accounts[index].setAddr(addr);
        return true;
    }
    public double getTotalBalance() {
        double total = 0.0;
        for (int i = 0; i < numAccounts; i++) {
            total += accounts[i].getBalance();
        }
        return total;
    }

    public void bankInfo() {
        System.out.println("Bank Name: " + getBankName());
        System.out.println("Number of Accounts: " + numAccounts);
        for (int i = 0; i < numAccounts; i++) {
            System.out.printf("  %d: $%.2f - %s: %s\n", accounts[i].getAccNum(), accounts[i].getBalance(), accounts[i].getName(), accounts[i].getSsn());
        }
        System.out.printf("Bank Total Balance: $%.2f\n", getTotalBalance());
    }
}